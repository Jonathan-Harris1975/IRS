import express from "express";
import mobileUxRoutes from "./mobileUx.js";
import digitalGrowthRoutes from "./digitalGrowth.js";
import websiteRoutes from "./website.js";
import seoAeoGeoRoutes from "./seoAeoGeo.js";
import onBrandRoutes from "./onBrand.js";
import socialPerformanceRoutes from "./socialPerformance.js";
import brandSocialCouncilRoutes from "./brandSocialCouncil.js";
import podcastWebsiteRoutes from "./podcastWebsite.js";
import newsletterAuditRoutes from "./newsletter.js";
import contentMasterRoutes from "./contentMaster.js";
import monthlyRoutes from "./monthly.js";

const router = express.Router();

router.use("/website", websiteRoutes);
router.use("/digital-growth", digitalGrowthRoutes);
router.use("/mobile-ux", mobileUxRoutes);
router.use("/seo-aeo-geo", seoAeoGeoRoutes);
router.use("/on-brand", onBrandRoutes);
router.use("/social-performance", socialPerformanceRoutes);
router.use("/brand-social-council", brandSocialCouncilRoutes);
router.use("/podcast-website", podcastWebsiteRoutes);
router.use("/newsletter", newsletterAuditRoutes);
router.use("/content-master", contentMasterRoutes);
router.use("/monthly", monthlyRoutes);

export default router;
